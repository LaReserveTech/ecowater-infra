For users, docs are now available at http://chardet.readthedocs.org.

For devs, you can edit the RST files in this directory.
