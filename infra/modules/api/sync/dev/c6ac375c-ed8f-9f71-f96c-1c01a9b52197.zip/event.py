from enum import Enum

class Event(Enum):
    DECREE_CREATION = 'decree_creation'
    DECREE_REPEAL = 'decree_repeal'
